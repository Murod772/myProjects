function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["active-drivers-active-drivers-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.html":
  /*!************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.html ***!
    \************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesDispatcherDriversActiveDriversActiveDriversPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Drivers</ion-title>\n    <ion-buttons slot=\"end\" color=\"warning\">\n      <ion-button [routerLink]=\"['/', 'dispatcher', 'drivers', 'add']\">\n        <ion-icon id=\"adds\" name=\"add-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-buttons>\n    <ion-button (click)=\"getLoc()\">\n      Click\n    </ion-button>\n  </ion-buttons>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers-routing.module.ts":
  /*!******************************************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/active-drivers/active-drivers-routing.module.ts ***!
    \******************************************************************************************/

  /*! exports provided: ActiveDriversPageRoutingModule */

  /***/
  function srcAppPagesDispatcherDriversActiveDriversActiveDriversRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActiveDriversPageRoutingModule", function () {
      return ActiveDriversPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _active_drivers_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./active-drivers.page */
    "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.ts");

    var routes = [{
      path: '',
      component: _active_drivers_page__WEBPACK_IMPORTED_MODULE_3__["ActiveDriversPage"]
    }];

    var ActiveDriversPageRoutingModule = function ActiveDriversPageRoutingModule() {
      _classCallCheck(this, ActiveDriversPageRoutingModule);
    };

    ActiveDriversPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ActiveDriversPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.module.ts":
  /*!**********************************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.module.ts ***!
    \**********************************************************************************/

  /*! exports provided: ActiveDriversPageModule */

  /***/
  function srcAppPagesDispatcherDriversActiveDriversActiveDriversModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActiveDriversPageModule", function () {
      return ActiveDriversPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _active_drivers_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./active-drivers-routing.module */
    "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers-routing.module.ts");
    /* harmony import */


    var _active_drivers_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./active-drivers.page */
    "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.ts");

    var ActiveDriversPageModule = function ActiveDriversPageModule() {
      _classCallCheck(this, ActiveDriversPageModule);
    };

    ActiveDriversPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _active_drivers_routing_module__WEBPACK_IMPORTED_MODULE_5__["ActiveDriversPageRoutingModule"]],
      declarations: [_active_drivers_page__WEBPACK_IMPORTED_MODULE_6__["ActiveDriversPage"]]
    })], ActiveDriversPageModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.scss":
  /*!**********************************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.scss ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesDispatcherDriversActiveDriversActiveDriversPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvZHJpdmVycy9hY3RpdmUtZHJpdmVycy9hY3RpdmUtZHJpdmVycy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.ts ***!
    \********************************************************************************/

  /*! exports provided: ActiveDriversPage */

  /***/
  function srcAppPagesDispatcherDriversActiveDriversActiveDriversPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActiveDriversPage", function () {
      return ActiveDriversPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var src_app_services_drivers_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! src/app/services/drivers.service */
    "./src/app/services/drivers.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var ActiveDriversPage = /*#__PURE__*/function () {
      function ActiveDriversPage(driversService) {
        _classCallCheck(this, ActiveDriversPage);

        this.driversService = driversService;
      }

      _createClass(ActiveDriversPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "getLoc",
        value: function getLoc() {
          this.driversService.getLocations().subscribe(function (locations) {
            console.log(locations);
          });
        }
      }]);

      return ActiveDriversPage;
    }();

    ActiveDriversPage.ctorParameters = function () {
      return [{
        type: src_app_services_drivers_service__WEBPACK_IMPORTED_MODULE_1__["DriversService"]
      }];
    };

    ActiveDriversPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-active-drivers',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./active-drivers.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./active-drivers.page.scss */
      "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.page.scss"))["default"]]
    })], ActiveDriversPage);
    /***/
  }
}]);
//# sourceMappingURL=active-drivers-active-drivers-module-es5.js.map