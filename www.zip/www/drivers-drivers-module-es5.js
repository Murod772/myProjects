function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["drivers-drivers-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/drivers.page.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/drivers.page.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesDispatcherDriversDriversPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n  <ion-tabs>\n    <ion-tab-bar color=\"light\" slot=\"bottom\">\n      <ion-tab-button tab=\"active\">\n        <ion-label>Active</ion-label>\n        <ion-icon name=\"flash\"></ion-icon>\n      </ion-tab-button>\n      <ion-tab-button tab=\"inactive\">\n        <ion-label>Inactive</ion-label>\n        <ion-icon name=\"flash-off\"></ion-icon>\n      </ion-tab-button>\n    </ion-tab-bar>\n  </ion-tabs>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/drivers-routing.module.ts":
  /*!********************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/drivers-routing.module.ts ***!
    \********************************************************************/

  /*! exports provided: DriversPageRoutingModule */

  /***/
  function srcAppPagesDispatcherDriversDriversRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DriversPageRoutingModule", function () {
      return DriversPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _drivers_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./drivers.page */
    "./src/app/pages/dispatcher/drivers/drivers.page.ts");

    var routes = [{
      path: '',
      component: _drivers_page__WEBPACK_IMPORTED_MODULE_3__["DriversPage"],
      children: [{
        path: 'active',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | active-drivers-active-drivers-module */
            [__webpack_require__.e("common"), __webpack_require__.e("active-drivers-active-drivers-module")]).then(__webpack_require__.bind(null,
            /*! ./active-drivers/active-drivers.module */
            "./src/app/pages/dispatcher/drivers/active-drivers/active-drivers.module.ts")).then(function (m) {
              return m.ActiveDriversPageModule;
            });
          }
        }, {
          path: 'add',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | add-driver-add-driver-module */
            [__webpack_require__.e("common"), __webpack_require__.e("add-driver-add-driver-module")]).then(__webpack_require__.bind(null,
            /*! ./add-driver/add-driver.module */
            "./src/app/pages/dispatcher/drivers/add-driver/add-driver.module.ts")).then(function (m) {
              return m.AddDriverPageModule;
            });
          }
        }]
      }, {
        path: 'inactive',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | inactive-drivers-inactive-drivers-module */
            [__webpack_require__.e("common"), __webpack_require__.e("inactive-drivers-inactive-drivers-module")]).then(__webpack_require__.bind(null,
            /*! ./inactive-drivers/inactive-drivers.module */
            "./src/app/pages/dispatcher/drivers/inactive-drivers/inactive-drivers.module.ts")).then(function (m) {
              return m.InactiveDriversPageModule;
            });
          }
        }, // {
        //   path: 'edit/:driverId',
        //   loadChildren: () => import('./inactive-drivers/edit-driver/edit-driver.module').then(m => m.EditDriverPageModule)
        // },
        {
          path: ':driverId',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | inactive-drivers-driver-details-driver-details-module */
            "driver-details-driver-details-module").then(__webpack_require__.bind(null,
            /*! ./inactive-drivers/driver-details/driver-details.module */
            "./src/app/pages/dispatcher/drivers/inactive-drivers/driver-details/driver-details.module.ts")).then(function (m) {
              return m.DriverDetailsPageModule;
            });
          }
        }]
      }, {
        path: 'add',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | add-driver-add-driver-module */
            [__webpack_require__.e("common"), __webpack_require__.e("add-driver-add-driver-module")]).then(__webpack_require__.bind(null,
            /*! ./add-driver/add-driver.module */
            "./src/app/pages/dispatcher/drivers/add-driver/add-driver.module.ts")).then(function (m) {
              return m.AddDriverPageModule;
            });
          }
        }]
      }]
    }];

    var DriversPageRoutingModule = function DriversPageRoutingModule() {
      _classCallCheck(this, DriversPageRoutingModule);
    };

    DriversPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DriversPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/drivers.module.ts":
  /*!************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/drivers.module.ts ***!
    \************************************************************/

  /*! exports provided: DriversPageModule */

  /***/
  function srcAppPagesDispatcherDriversDriversModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DriversPageModule", function () {
      return DriversPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _drivers_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./drivers-routing.module */
    "./src/app/pages/dispatcher/drivers/drivers-routing.module.ts");
    /* harmony import */


    var _drivers_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./drivers.page */
    "./src/app/pages/dispatcher/drivers/drivers.page.ts");

    var DriversPageModule = function DriversPageModule() {
      _classCallCheck(this, DriversPageModule);
    };

    DriversPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _drivers_routing_module__WEBPACK_IMPORTED_MODULE_5__["DriversPageRoutingModule"]],
      declarations: [_drivers_page__WEBPACK_IMPORTED_MODULE_6__["DriversPage"]]
    })], DriversPageModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/drivers.page.scss":
  /*!************************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/drivers.page.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesDispatcherDriversDriversPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvZHJpdmVycy9kcml2ZXJzLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/drivers/drivers.page.ts":
  /*!**********************************************************!*\
    !*** ./src/app/pages/dispatcher/drivers/drivers.page.ts ***!
    \**********************************************************/

  /*! exports provided: DriversPage */

  /***/
  function srcAppPagesDispatcherDriversDriversPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DriversPage", function () {
      return DriversPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var DriversPage = /*#__PURE__*/function () {
      function DriversPage() {
        _classCallCheck(this, DriversPage);
      }

      _createClass(DriversPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return DriversPage;
    }();

    DriversPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-drivers',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./drivers.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/drivers.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./drivers.page.scss */
      "./src/app/pages/dispatcher/drivers/drivers.page.scss"))["default"]]
    })], DriversPage);
    /***/
  }
}]);
//# sourceMappingURL=drivers-drivers-module-es5.js.map