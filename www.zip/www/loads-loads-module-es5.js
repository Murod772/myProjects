function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loads-loads-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/loads.page.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/loads.page.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesDispatcherLoadsLoadsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n  <ion-tabs>\n    <ion-tab-bar color=\"light\" slot=\"bottom\">\n      <ion-tab-button tab=\"current\">\n        <ion-label>Current Loads</ion-label>\n        <ion-icon name=\"file-tray\"></ion-icon>\n      </ion-tab-button>\n      <ion-tab-button tab=\"past\">\n        <ion-label>Past Loads</ion-label>\n        <ion-icon name=\"file-tray-stacked\"></ion-icon>\n      </ion-tab-button>\n    </ion-tab-bar>\n  </ion-tabs>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/loads-routing.module.ts":
  /*!****************************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/loads-routing.module.ts ***!
    \****************************************************************/

  /*! exports provided: LoadsPageRoutingModule */

  /***/
  function srcAppPagesDispatcherLoadsLoadsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoadsPageRoutingModule", function () {
      return LoadsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _loads_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./loads.page */
    "./src/app/pages/dispatcher/loads/loads.page.ts");

    var routes = [{
      path: '',
      component: _loads_page__WEBPACK_IMPORTED_MODULE_3__["LoadsPage"],
      children: [{
        path: 'current',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | current-load-current-load-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common"), __webpack_require__.e("current-load-current-load-module")]).then(__webpack_require__.bind(null,
            /*! ./current-load/current-load.module */
            "./src/app/pages/dispatcher/loads/current-load/current-load.module.ts")).then(function (m) {
              return m.CurrentLoadPageModule;
            });
          }
        }, {
          path: 'assign',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | assign-load-assign-load-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common"), __webpack_require__.e("assign-load-assign-load-module")]).then(__webpack_require__.bind(null,
            /*! ./assign-load/assign-load.module */
            "./src/app/pages/dispatcher/loads/assign-load/assign-load.module.ts")).then(function (m) {
              return m.AssignLoadPageModule;
            });
          }
        }, {
          path: 'edit/:loadId',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | current-load-edit-load-edit-load-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common")]).then(__webpack_require__.bind(null,
            /*! ./current-load/edit-load/edit-load.module */
            "./src/app/pages/dispatcher/loads/current-load/edit-load/edit-load.module.ts")).then(function (m) {
              return m.EditLoadPageModule;
            });
          }
        }, {
          path: ':loadId',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | current-load-current-details-current-details-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common")]).then(__webpack_require__.bind(null,
            /*! ./current-load/current-details/current-details.module */
            "./src/app/pages/dispatcher/loads/current-load/current-details/current-details.module.ts")).then(function (m) {
              return m.CurrentDetailsPageModule;
            });
          }
        }]
      }, {
        path: 'past',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | past-load-past-load-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common"), __webpack_require__.e("past-load-past-load-module")]).then(__webpack_require__.bind(null,
            /*! ./past-load/past-load.module */
            "./src/app/pages/dispatcher/loads/past-load/past-load.module.ts")).then(function (m) {
              return m.PastLoadPageModule;
            });
          }
        }, {
          path: 'edit/:loadId',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | past-load-edit-load-edit-load-module */
            "common").then(__webpack_require__.bind(null,
            /*! ./past-load/edit-load/edit-load.module */
            "./src/app/pages/dispatcher/loads/past-load/edit-load/edit-load.module.ts")).then(function (m) {
              return m.EditLoadPageModule;
            });
          }
        }, {
          path: ':loadId',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | past-load-past-details-past-details-module */
            "past-details-past-details-module").then(__webpack_require__.bind(null,
            /*! ./past-load/past-details/past-details.module */
            "./src/app/pages/dispatcher/loads/past-load/past-details/past-details.module.ts")).then(function (m) {
              return m.PastDetailsPageModule;
            });
          }
        }]
      }, {
        path: 'assign',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | assign-load-assign-load-module */
            [__webpack_require__.e("default~assign-load-assign-load-module~current-load-current-details-current-details-module~current-l~72fc5e30"), __webpack_require__.e("common"), __webpack_require__.e("assign-load-assign-load-module")]).then(__webpack_require__.bind(null,
            /*! ./assign-load/assign-load.module */
            "./src/app/pages/dispatcher/loads/assign-load/assign-load.module.ts")).then(function (m) {
              return m.AssignLoadPageModule;
            });
          }
        }]
      }]
    }];

    var LoadsPageRoutingModule = function LoadsPageRoutingModule() {
      _classCallCheck(this, LoadsPageRoutingModule);
    };

    LoadsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], LoadsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/loads.module.ts":
  /*!********************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/loads.module.ts ***!
    \********************************************************/

  /*! exports provided: LoadsPageModule */

  /***/
  function srcAppPagesDispatcherLoadsLoadsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoadsPageModule", function () {
      return LoadsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _loads_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./loads-routing.module */
    "./src/app/pages/dispatcher/loads/loads-routing.module.ts");
    /* harmony import */


    var _loads_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./loads.page */
    "./src/app/pages/dispatcher/loads/loads.page.ts");

    var LoadsPageModule = function LoadsPageModule() {
      _classCallCheck(this, LoadsPageModule);
    };

    LoadsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _loads_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoadsPageRoutingModule"]],
      declarations: [_loads_page__WEBPACK_IMPORTED_MODULE_6__["LoadsPage"]]
    })], LoadsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/loads.page.scss":
  /*!********************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/loads.page.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesDispatcherLoadsLoadsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvbG9hZHMvbG9hZHMucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/loads.page.ts":
  /*!******************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/loads.page.ts ***!
    \******************************************************/

  /*! exports provided: LoadsPage */

  /***/
  function srcAppPagesDispatcherLoadsLoadsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoadsPage", function () {
      return LoadsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var LoadsPage = /*#__PURE__*/function () {
      function LoadsPage() {
        _classCallCheck(this, LoadsPage);
      }

      _createClass(LoadsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return LoadsPage;
    }();

    LoadsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-loads',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./loads.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/loads.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./loads.page.scss */
      "./src/app/pages/dispatcher/loads/loads.page.scss"))["default"]]
    })], LoadsPage);
    /***/
  }
}]);
//# sourceMappingURL=loads-loads-module-es5.js.map