(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-driver-add-driver-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/dispatcher/drivers/active\"></ion-back-button>\n  </ion-buttons>\n    <ion-title>New Driver</ion-title>\n    <!-- <ion-buttons slot=\"primary\">\n      <ion-button color=\"dark\" (click)=\"onCreateLoad()\" [disabled]=\"!form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons> -->\n  </ion-toolbar>\n  </ion-header>\n\n  <ion-content>\n    <!-- <form [formGroup]=\"form\" > -->\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-card>\n            <ion-card-header>\n              <div class = \"ion-text-center\">\n                <ion-card-title>Add New Driver</ion-card-title>\n              </div>\n            </ion-card-header>\n            <ion-card-content>\n              <ion-item>\n                <ion-label position=\"floating\">Driver Name or Email</ion-label>\n                <ion-input [(ngModel)]=\"participant\" type=\"text\" autocomplete autocorrect></ion-input>\n              </ion-item>\n              <div class = \"ion-text-center ion-padding\">\n                <ion-button expand=\"full\" (click)=\"addDriver()\">Search</ion-button>\n              </div>\n              <!-- <div class = \"ion-text-center ion-padding\">\n                <ion-button expand=\"full\" (click)=\"check()\">Check</ion-button>\n              </div>\n              <div class = \"ion-text-center ion-padding\">\n                <ion-button expand=\"full\" (click)=\"checkOther() \">Check</ion-button>\n              </div> -->\n              <ion-item *ngFor=\"let usr of users\">\n                <ion-label>\n                  {{ usr.email }}\n                  <p>{{ usr.name }}</p>\n                  <p>{{ usr.mc }}</p>\n                </ion-label>\n                    <!-- <ion-button color=\"danger\" size=\"medium\" fill=\"clear\"  (click)=\"onCancelDriver(usr.id)\" slot=\"end\">\n                      <ion-icon slot=\"icon-only\" name=\"close-outline\"></ion-icon>\n                    </ion-button> -->\n              </ion-item>          \n            </ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  <!-- </form> -->\n  </ion-content>");

/***/ }),

/***/ "./src/app/pages/dispatcher/drivers/add-driver/add-driver-routing.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/dispatcher/drivers/add-driver/add-driver-routing.module.ts ***!
  \**********************************************************************************/
/*! exports provided: AddDriverPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddDriverPageRoutingModule", function() { return AddDriverPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_driver_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-driver.page */ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.ts");




const routes = [
    {
        path: '',
        component: _add_driver_page__WEBPACK_IMPORTED_MODULE_3__["AddDriverPage"]
    }
];
let AddDriverPageRoutingModule = class AddDriverPageRoutingModule {
};
AddDriverPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddDriverPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dispatcher/drivers/add-driver/add-driver.module.ts ***!
  \**************************************************************************/
/*! exports provided: AddDriverPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddDriverPageModule", function() { return AddDriverPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_driver_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-driver-routing.module */ "./src/app/pages/dispatcher/drivers/add-driver/add-driver-routing.module.ts");
/* harmony import */ var _add_driver_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-driver.page */ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.ts");







let AddDriverPageModule = class AddDriverPageModule {
};
AddDriverPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _add_driver_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddDriverPageRoutingModule"]
        ],
        declarations: [_add_driver_page__WEBPACK_IMPORTED_MODULE_6__["AddDriverPage"]]
    })
], AddDriverPageModule);



/***/ }),

/***/ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvZHJpdmVycy9hZGQtZHJpdmVyL2FkZC1kcml2ZXIucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.ts ***!
  \************************************************************************/
/*! exports provided: AddDriverPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddDriverPage", function() { return AddDriverPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var src_app_services_drivers_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/drivers.service */ "./src/app/services/drivers.service.ts");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth.service */ "./src/app/services/auth.service.ts");





let AddDriverPage = class AddDriverPage {
    constructor(driverService, auth) {
        this.driverService = driverService;
        this.auth = auth;
        this.users = [];
        this.participant = '';
    }
    ngOnInit() {
    }
    addDriver() {
        const obs = this.driverService.findUser(this.participant);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["forkJoin"])(obs).subscribe(res => {
            if (!res) {
                return console.log('Got undefined');
            }
            for (let data of res) {
                if (data.length > 0) {
                    this.users.push(data[0]);
                }
                console.log(res);
            }
            console.log('it works:', this.participant);
            this.participant = '';
        }, error => {
            console.log('Here you got an error: ', error);
        });
    }
};
AddDriverPage.ctorParameters = () => [
    { type: src_app_services_drivers_service__WEBPACK_IMPORTED_MODULE_3__["DriversService"] },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
];
AddDriverPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-driver',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-driver.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-driver.page.scss */ "./src/app/pages/dispatcher/drivers/add-driver/add-driver.page.scss")).default]
    })
], AddDriverPage);



/***/ })

}]);
//# sourceMappingURL=add-driver-add-driver-module-es2015.js.map