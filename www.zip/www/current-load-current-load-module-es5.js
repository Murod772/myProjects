function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["current-load-current-load-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/current-load/current-load.page.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/current-load/current-load.page.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesDispatcherLoadsCurrentLoadCurrentLoadPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Loads</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button  [routerLink]=\"['/', 'dispatcher', 'loads', 'assign']\">\n        <ion-icon id=\"adds\" name=\"add-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row >\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" >\n        <div class=\"ion-text-center\" *ngIf=\"isLoading\" >\n          <ion-spinner color=\"primary\"></ion-spinner>\n        </div>\n        <div class=\"ion-text-center\" *ngIf=\"!isLoading && loads.length <= 0\"><p>No Loads Yet</p></div>\n\n        <ion-list *ngIf=\"!isLoading && loads.length > 0\" id=\"list\" lines=\"none\">\n          <ion-item id=\"item\"  *ngFor=\"let load of loads\">\n            <ion-grid>\n              <ion-row>\n                <ion-col>\n                  <div id=\"time\" class=\"ion-text-center\">{{ load.date | date:'short' }}</div>\n                  <ion-card id=\"card\">\n                    <div class=\"ion-text-right\"> \n                      <ion-button fill=\"clear\" [routerLink]=\"['/', 'dispatcher', 'loads','current','edit', load.id]\"><ion-icon slot=\"icon-only\" name=\"create-outline\"></ion-icon></ion-button>\n                    </div>\n                    <ion-grid>\n                        <ion-row>\n                            <ion-col>\n                              <ion-card-content>\n                                <p id=\"passive\">{{\"Status\"}}</p>\n                                <div id=\"status\">{{ load.status }}</div>\n                                </ion-card-content>\n                              </ion-col>\n                              <ion-col>\n                                  <ion-card-content>\n                                      <p id=\"passive\">{{\"Distance\"}}</p>\n                                      <div>{{ load.distance | number}} mile</div>\n                                    </ion-card-content>\n                              </ion-col>\n                          </ion-row>\n                          <ion-row>\n                              <ion-col>\n                                  <ion-card-content>\n                                      <p id=\"passive\">{{\"Driver Name\"}}</p>\n                                      <div>{{ load.driverName }}</div>\n                                    </ion-card-content>\n                              </ion-col>\n                              <ion-col>\n                                  <ion-card-content>\n                                      <p id=\"passive\">{{\"ID\"}}</p>\n                                      <div>{{ load.loadNumber }}</div>\n                                    </ion-card-content>\n                              </ion-col>\n                          </ion-row>\n                          <ion-row>\n                              <ion-col>\n                                  <ion-card-content>\n                                      <p id=\"passive\">{{\"From\"}}</p>\n                                      <div>{{ load.from }}</div>\n                                    </ion-card-content>\n                              </ion-col>\n                              <ion-col>\n                                  <ion-card-content>\n                                      <p id=\"passive\">{{\"To\"}}</p>\n                                      <div>{{ load.to }}</div>\n                                    </ion-card-content>\n                              </ion-col>\n                          </ion-row>\n                      </ion-grid>\n                      <div> \n                      <ion-button fill=\"clear\" shape=\"round\" expand=\"full\" color=\"primary\" [routerLink]=\"[load.id]\">More</ion-button>\n                      </div>\n                  </ion-card>\n               </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/current-load/current-load-routing.module.ts":
  /*!************************************************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/current-load/current-load-routing.module.ts ***!
    \************************************************************************************/

  /*! exports provided: CurrentLoadPageRoutingModule */

  /***/
  function srcAppPagesDispatcherLoadsCurrentLoadCurrentLoadRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrentLoadPageRoutingModule", function () {
      return CurrentLoadPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _current_load_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./current-load.page */
    "./src/app/pages/dispatcher/loads/current-load/current-load.page.ts");

    var routes = [{
      path: '',
      component: _current_load_page__WEBPACK_IMPORTED_MODULE_3__["CurrentLoadPage"]
    }, {
      path: 'current-details',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | current-details-current-details-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./current-details/current-details.module */
        "./src/app/pages/dispatcher/loads/current-load/current-details/current-details.module.ts")).then(function (m) {
          return m.CurrentDetailsPageModule;
        });
      }
    }, {
      path: 'edit-load',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | edit-load-edit-load-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./edit-load/edit-load.module */
        "./src/app/pages/dispatcher/loads/current-load/edit-load/edit-load.module.ts")).then(function (m) {
          return m.EditLoadPageModule;
        });
      }
    }];

    var CurrentLoadPageRoutingModule = function CurrentLoadPageRoutingModule() {
      _classCallCheck(this, CurrentLoadPageRoutingModule);
    };

    CurrentLoadPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CurrentLoadPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/current-load/current-load.module.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/current-load/current-load.module.ts ***!
    \****************************************************************************/

  /*! exports provided: CurrentLoadPageModule */

  /***/
  function srcAppPagesDispatcherLoadsCurrentLoadCurrentLoadModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrentLoadPageModule", function () {
      return CurrentLoadPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _current_load_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./current-load-routing.module */
    "./src/app/pages/dispatcher/loads/current-load/current-load-routing.module.ts");
    /* harmony import */


    var _current_load_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./current-load.page */
    "./src/app/pages/dispatcher/loads/current-load/current-load.page.ts");

    var CurrentLoadPageModule = function CurrentLoadPageModule() {
      _classCallCheck(this, CurrentLoadPageModule);
    };

    CurrentLoadPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _current_load_routing_module__WEBPACK_IMPORTED_MODULE_5__["CurrentLoadPageRoutingModule"]],
      declarations: [_current_load_page__WEBPACK_IMPORTED_MODULE_6__["CurrentLoadPage"]]
    })], CurrentLoadPageModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/current-load/current-load.page.scss":
  /*!****************************************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/current-load/current-load.page.scss ***!
    \****************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesDispatcherLoadsCurrentLoadCurrentLoadPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvbG9hZHMvY3VycmVudC1sb2FkL2N1cnJlbnQtbG9hZC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/loads/current-load/current-load.page.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/pages/dispatcher/loads/current-load/current-load.page.ts ***!
    \**************************************************************************/

  /*! exports provided: CurrentLoadPage */

  /***/
  function srcAppPagesDispatcherLoadsCurrentLoadCurrentLoadPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrentLoadPage", function () {
      return CurrentLoadPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _services_loads_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../../../services/loads.service */
    "./src/app/services/loads.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var CurrentLoadPage = /*#__PURE__*/function () {
      function CurrentLoadPage(loadsService) {
        _classCallCheck(this, CurrentLoadPage);

        this.loadsService = loadsService;
        this.match = 'Ready';
        this.loads = [];
        this.isLoading = false;
      }

      _createClass(CurrentLoadPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          console.log('Hello');

          if (!this.loadsService.getLoad()) {
            setTimeout(function () {
              _this.isLoading = true;
              _this.loadsSub = _this.loadsService.getLoad().subscribe(function (res) {
                var newLoad = [];
                res.map(function (load) {
                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            if (!(load.status == this.match)) {
                              _context.next = 4;
                              break;
                            }

                            newLoad.push(load)
                            /**if it is ready type load then add it to newload array */
                            ;
                            _context.next = 6;
                            break;

                          case 4:
                            _context.next = 6;
                            return this.loadsService.deleteLoad(load.id, load);

                          case 6:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee, this);
                  }));
                });
                _this.loads = newLoad; //now it will only have loads that are Ready

                _this.isLoading = false;
              });
            }, 500);
          } else {
            this.isLoading = true;
            this.loadsSub = this.loadsService.getLoad().subscribe(function (res) {
              var newLoad = [];
              res.map(function (load) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                  return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                      switch (_context2.prev = _context2.next) {
                        case 0:
                          if (!(load.status == this.match)) {
                            _context2.next = 4;
                            break;
                          }

                          newLoad.push(load)
                          /**if it is ready type load then add it to newload array */
                          ;
                          _context2.next = 6;
                          break;

                        case 4:
                          _context2.next = 6;
                          return this.loadsService.deleteLoad(load.id, load);

                        case 6:
                        case "end":
                          return _context2.stop();
                      }
                    }
                  }, _callee2, this);
                }));
              });
              _this.loads = newLoad; //now it will only have loads that are Ready

              _this.isLoading = false;
            });
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.loadsSub) {
            this.loadsSub.unsubscribe();
          }
        }
      }]);

      return CurrentLoadPage;
    }();

    CurrentLoadPage.ctorParameters = function () {
      return [{
        type: _services_loads_service__WEBPACK_IMPORTED_MODULE_1__["LoadsService"]
      }];
    };

    CurrentLoadPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-current-load',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./current-load.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/current-load/current-load.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./current-load.page.scss */
      "./src/app/pages/dispatcher/loads/current-load/current-load.page.scss"))["default"]]
    })], CurrentLoadPage);
    /***/
  }
}]);
//# sourceMappingURL=current-load-current-load-module-es5.js.map