function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-dispatcher-dispatcher-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/dispatcher.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/dispatcher.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesDispatcherDispatcherPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Dispatcher</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"signOut()\">\n        <ion-icon slot=\"icon-only\" name=\"log-out\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/dispatcher-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/dispatcher/dispatcher-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: DispatcherPageRoutingModule */

  /***/
  function srcAppPagesDispatcherDispatcherRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DispatcherPageRoutingModule", function () {
      return DispatcherPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _dispatcher_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./dispatcher.page */
    "./src/app/pages/dispatcher/dispatcher.page.ts");

    var routes = [{
      path: '',
      component: _dispatcher_page__WEBPACK_IMPORTED_MODULE_3__["DispatcherPage"]
    }, {
      path: 'loads',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | loads-loads-module */
        "loads-loads-module").then(__webpack_require__.bind(null,
        /*! ./loads/loads.module */
        "./src/app/pages/dispatcher/loads/loads.module.ts")).then(function (m) {
          return m.LoadsPageModule;
        });
      }
    }, {
      path: 'drivers',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | drivers-drivers-module */
        "drivers-drivers-module").then(__webpack_require__.bind(null,
        /*! ./drivers/drivers.module */
        "./src/app/pages/dispatcher/drivers/drivers.module.ts")).then(function (m) {
          return m.DriversPageModule;
        });
      }
    }, {
      path: 'trailers',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | trailers-trailers-module */
        "trailers-trailers-module").then(__webpack_require__.bind(null,
        /*! ./trailers/trailers.module */
        "./src/app/pages/dispatcher/trailers/trailers.module.ts")).then(function (m) {
          return m.TrailersPageModule;
        });
      }
    }, {
      path: 'notifications',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | notifications-notifications-module */
        "notifications-notifications-module").then(__webpack_require__.bind(null,
        /*! ./notifications/notifications.module */
        "./src/app/pages/dispatcher/notifications/notifications.module.ts")).then(function (m) {
          return m.NotificationsPageModule;
        });
      }
    }, {
      path: 'settings',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | settings-settings-module */
        "settings-settings-module").then(__webpack_require__.bind(null,
        /*! ./settings/settings.module */
        "./src/app/pages/dispatcher/settings/settings.module.ts")).then(function (m) {
          return m.SettingsPageModule;
        });
      }
    }, {
      path: 'profile',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | profile-profile-module */
        "profile-profile-module").then(__webpack_require__.bind(null,
        /*! ./profile/profile.module */
        "./src/app/pages/dispatcher/profile/profile.module.ts")).then(function (m) {
          return m.ProfilePageModule;
        });
      }
    }];

    var DispatcherPageRoutingModule = function DispatcherPageRoutingModule() {
      _classCallCheck(this, DispatcherPageRoutingModule);
    };

    DispatcherPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DispatcherPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/dispatcher.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/dispatcher/dispatcher.module.ts ***!
    \*******************************************************/

  /*! exports provided: DispatcherPageModule */

  /***/
  function srcAppPagesDispatcherDispatcherModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DispatcherPageModule", function () {
      return DispatcherPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _dispatcher_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./dispatcher-routing.module */
    "./src/app/pages/dispatcher/dispatcher-routing.module.ts");
    /* harmony import */


    var _dispatcher_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dispatcher.page */
    "./src/app/pages/dispatcher/dispatcher.page.ts");

    var DispatcherPageModule = function DispatcherPageModule() {
      _classCallCheck(this, DispatcherPageModule);
    };

    DispatcherPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _dispatcher_routing_module__WEBPACK_IMPORTED_MODULE_5__["DispatcherPageRoutingModule"]],
      declarations: [_dispatcher_page__WEBPACK_IMPORTED_MODULE_6__["DispatcherPage"]]
    })], DispatcherPageModule);
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/dispatcher.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/dispatcher/dispatcher.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesDispatcherDispatcherPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvZGlzcGF0Y2hlci5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/dispatcher/dispatcher.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/dispatcher/dispatcher.page.ts ***!
    \*****************************************************/

  /*! exports provided: DispatcherPage */

  /***/
  function srcAppPagesDispatcherDispatcherPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DispatcherPage", function () {
      return DispatcherPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../services/auth.service */
    "./src/app/services/auth.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../../app.component */
    "./src/app/app.component.ts");

    var DispatcherPage = /*#__PURE__*/function () {
      function DispatcherPage(auth, comp) {
        _classCallCheck(this, DispatcherPage);

        this.auth = auth;
        this.comp = comp;
      }

      _createClass(DispatcherPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "signOut",
        value: function signOut() {
          this.auth.signOut();
        }
      }]);

      return DispatcherPage;
    }();

    DispatcherPage.ctorParameters = function () {
      return [{
        type: _services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]
      }, {
        type: _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]
      }];
    };

    DispatcherPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-dispatcher',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./dispatcher.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/dispatcher.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./dispatcher.page.scss */
      "./src/app/pages/dispatcher/dispatcher.page.scss"))["default"]]
    })], DispatcherPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-dispatcher-dispatcher-module-es5.js.map