(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["assign-load-assign-load-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/assign-load/assign-load.page.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/assign-load/assign-load.page.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/dispatcher/loads/current\"></ion-back-button>\n  </ion-buttons>\n    <ion-title>New Load</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button color=\"dark\" (click)=\"onCreateLoad()\" [disabled]=\"!form.valid\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  </ion-header>\n  \n  <ion-content>\n    <form [formGroup]=\"form\" >\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-card>\n            <ion-card-header>\n              <div class = \"ion-text-center\">\n                <ion-card-title>Assign New Load</ion-card-title>\n              </div>\n            </ion-card-header>\n            <ion-card-content>\n              <ion-item>\n                <ion-label position=\"floating\">Driver Name</ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"driverName\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">Load ID</ion-label>\n                <ion-input type=\"number\" formControlName=\"loadNumber\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">From</ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"from\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">To</ion-label>\n                <ion-input type=\"text\" autocomplete autocorrect formControlName=\"to\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">Status</ion-label>\n                <ion-input type=\"text\" formControlName=\"status\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">Distance</ion-label>\n                <ion-input type=\"number\" formControlName=\"distance\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">Price</ion-label>\n                <ion-input type=\"number\" formControlName=\"price\"></ion-input>\n              </ion-item>\n            </ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n  </ion-content>\n");

/***/ }),

/***/ "./src/app/pages/dispatcher/loads/assign-load/assign-load-routing.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/dispatcher/loads/assign-load/assign-load-routing.module.ts ***!
  \**********************************************************************************/
/*! exports provided: AssignLoadPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignLoadPageRoutingModule", function() { return AssignLoadPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _assign_load_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./assign-load.page */ "./src/app/pages/dispatcher/loads/assign-load/assign-load.page.ts");




const routes = [
    {
        path: '',
        component: _assign_load_page__WEBPACK_IMPORTED_MODULE_3__["AssignLoadPage"]
    }
];
let AssignLoadPageRoutingModule = class AssignLoadPageRoutingModule {
};
AssignLoadPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AssignLoadPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/dispatcher/loads/assign-load/assign-load.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dispatcher/loads/assign-load/assign-load.module.ts ***!
  \**************************************************************************/
/*! exports provided: AssignLoadPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignLoadPageModule", function() { return AssignLoadPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _assign_load_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assign-load-routing.module */ "./src/app/pages/dispatcher/loads/assign-load/assign-load-routing.module.ts");
/* harmony import */ var _assign_load_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./assign-load.page */ "./src/app/pages/dispatcher/loads/assign-load/assign-load.page.ts");







let AssignLoadPageModule = class AssignLoadPageModule {
};
AssignLoadPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _assign_load_routing_module__WEBPACK_IMPORTED_MODULE_5__["AssignLoadPageRoutingModule"]
        ],
        declarations: [_assign_load_page__WEBPACK_IMPORTED_MODULE_6__["AssignLoadPage"]]
    })
], AssignLoadPageModule);



/***/ }),

/***/ "./src/app/pages/dispatcher/loads/assign-load/assign-load.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/dispatcher/loads/assign-load/assign-load.page.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc3BhdGNoZXIvbG9hZHMvYXNzaWduLWxvYWQvYXNzaWduLWxvYWQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/dispatcher/loads/assign-load/assign-load.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/dispatcher/loads/assign-load/assign-load.page.ts ***!
  \************************************************************************/
/*! exports provided: AssignLoadPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignLoadPage", function() { return AssignLoadPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_loads_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../../services/loads.service */ "./src/app/services/loads.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");





let AssignLoadPage = class AssignLoadPage {
    constructor(fb, loadsService, router) {
        this.fb = fb;
        this.loadsService = loadsService;
        this.router = router;
    }
    ngOnInit() {
        this.form = this.fb.group({
            driverName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            loadNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            from: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            to: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            status: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            distance: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            price: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
        });
    }
    onCreateLoad() {
        if (!this.form.valid) {
            return;
        }
        console.log('On create load works!');
        this.loadsService.addLoad(this.form.value).then(res => {
            this.form.reset();
            this.router.navigateByUrl('dispatcher/loads/current');
            return res;
        });
    }
};
AssignLoadPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _services_loads_service__WEBPACK_IMPORTED_MODULE_1__["LoadsService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
AssignLoadPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-assign-load',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./assign-load.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/dispatcher/loads/assign-load/assign-load.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./assign-load.page.scss */ "./src/app/pages/dispatcher/loads/assign-load/assign-load.page.scss")).default]
    })
], AssignLoadPage);



/***/ })

}]);
//# sourceMappingURL=assign-load-assign-load-module-es2015.js.map